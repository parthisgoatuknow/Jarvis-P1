package com.jarvis.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wantListen = false
    private val ui = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#02080F")
        window.navigationBarColor = Color.parseColor("#02080F")

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setLanguage(Locale.UK)
            }
        }

        web = WebView(this)
        setContentView(web)
        web.setBackgroundColor(Color.parseColor("#02080F"))
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "JarvisNative")
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                request.grant(request.resources)
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val host = Uri.parse(BuildConfig.START_URL).host
                if ((u.scheme == "http" || u.scheme == "https") && u.host == host) return false
                try {
                    if (u.scheme == "intent") {
                        startActivity(Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME))
                    } else {
                        startActivity(Intent(Intent.ACTION_VIEW, u))
                    }
                } catch (e: Exception) {
                }
                return true
            }
        }
        web.loadUrl(BuildConfig.START_URL)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun listen() { ui.post { startListening() } }

        @JavascriptInterface
        fun stopListening() { ui.post { rec?.stopListening() } }

        @JavascriptInterface
        fun speak(text: String, pitch: Double, rate: Double) { ui.post { say(text, pitch, rate) } }

        @JavascriptInterface
        fun stopSpeak() { ui.post { tts?.stop() } }

        @JavascriptInterface
        fun openApp(name: String): Boolean = launchByName(name)

        @JavascriptInterface
        fun openPackage(pkg: String): Boolean {
            val launch = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            ui.post { startActivity(launch) }
            return true
        }
    }

    private fun emit(type: String, text: String) {
        val code = "window.onNative&&window.onNative(" + JSONObject.quote(type) + "," + JSONObject.quote(text) + ")"
        ui.post { web.evaluateJavascript(code, null) }
    }

    private fun launchByName(name: String): Boolean {
        val q = name.lowercase().trim()
        if (q.isEmpty()) return false
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        var best: String? = null
        var score = 0
        for (ri in pm.queryIntentActivities(main, 0)) {
            val label = ri.loadLabel(pm).toString().lowercase()
            val sc = when {
                label == q -> 4
                label.startsWith(q) -> 3
                label.contains(q) -> 2
                label.length > 2 && q.contains(label) -> 1
                else -> 0
            }
            if (sc > score) {
                score = sc
                best = ri.activityInfo.packageName
            }
        }
        val pkg = best ?: return false
        val launch = pm.getLaunchIntentForPackage(pkg) ?: return false
        ui.post { startActivity(launch) }
        return true
    }

    private fun say(text: String, pitch: Double, rate: Double) {
        val t = tts
        if (t == null || !ttsReady) {
            emit("spoke", "")
            return
        }
        t.setPitch(pitch.toFloat())
        t.setSpeechRate(rate.toFloat())
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { emit("spoke", "") }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { emit("spoke", "") }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "j" + System.nanoTime())
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            wantListen = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            emit("error", "unavailable")
            return
        }
        tts?.stop()
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { emit("start", "") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                emit("error", if (quiet) "nomatch" else "e$error")
                emit("end", "")
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotEmpty()) emit("final", t)
                emit("end", "")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotEmpty()) emit("partial", t)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        r.startListening(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (wantListen) {
            wantListen = false
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening()
            else emit("error", "permission")
        }
    }

    override fun onDestroy() {
        rec?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
